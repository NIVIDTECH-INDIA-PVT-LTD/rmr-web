import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      {/* Top Info Bar - Hidden on mobile */}
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-[95%] sm:w-[90%] md:w-[85%] lg:w-[80%] z-50 bg-white">
        <div className="hidden sm:flex text-xs sm:text-sm py-3 px-4 sm:px-6 flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
          <p className="font-[Figtree] font-semibold text-[16px] leading-[100%] tracking-normal align-middle text-[#595959]">
            Get Free Business Consulting Today?{' '}
            <Link href="/contact" className="text-[#CD4D4A] border-b border-[#CD4D4A]">Contact Us</Link>
          </p>
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 font-medium text-[16px] leading-[100%] align-middle font-[Figtree] text-xs sm:text-sm">
            <p className='flex'><Image src="/images/mailicon.svg" alt="mail" width={20} height={20} className='pr-1' /> sales@rootmarketresearch.com</p>
          </div>
          
        </div>

        <div className="bg-transparent px-4 sm:px-6 py-2 flex flex-wrap justify-between items-center">
          <Link href="/">
            <Image src="/images/logo.svg" alt="Logo" width={130} height={35} className="object-contain" />
          </Link>
          
          {/* Mobile Menu Button - Only shows on mobile */}
          <button 
            className="md:hidden p-2 text-gray-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
          
          {/* Desktop Navigation - Unchanged */}
          <nav className="hidden md:flex flex-wrap items-center gap-4 md:gap-6 text-sm font-semibold mt-2 md:mt-0">
            <Link href="/" className='font-[Figtree] font-bold text-[15px] leading-[100%] tracking-normal text-center align-middle uppercase text-[#392761] border-b border-transparent hover:border-b-[#392761]'>HOME</Link>
            <Link href="/about" className='font-[Figtree] font-bold text-[15px] leading-[100%] tracking-normal text-center align-middle uppercase text-[#392761] border-b border-transparent hover:border-b-[#392761]'>ABOUT US</Link>
            <Link href="/services" className='font-[Figtree] font-bold text-[15px] leading-[100%] tracking-normal text-center align-middle uppercase text-[#392761] border-b border-transparent hover:border-b-[#392761]'>OUR SERVICES</Link>
            <Link href="/verticals" className='font-[Figtree] font-bold text-[15px] leading-[100%] tracking-normal text-center align-middle uppercase text-[#392761] border-b border-transparent hover:border-b-[#392761]'>INDUSTRY VERTICALS</Link>
            <Link href="/contact" className='font-[Figtree] font-bold text-[15px] leading-[100%] tracking-normal text-center align-middle uppercase text-[#392761] border-b border-transparent hover:border-b-[#392761]'>CONTACT US</Link>
          </nav>

          <div className="hidden md:flex flex-wrap gap-2">
              <Image src="/images/fbicon.svg" alt="fb" width={25} height={25} />
              <Image src="/images/linkdinicon.svg" alt="linkedin" width={25} height={25} />
            </div>
        </div>
        
        {/* Mobile Dropdown Menu - Only shows on mobile when toggled */}
        {isMenuOpen && (
          <div className="md:hidden bg-white px-4 pb-4 shadow-lg">
            <nav className="flex flex-col space-y-3">
              <Link href="/" className="py-2 border-b border-gray-100" onClick={() => setIsMenuOpen(false)}>HOME</Link>
              <Link href="/about" className="py-2 border-b border-gray-100" onClick={() => setIsMenuOpen(false)}>ABOUT US</Link>
              <Link href="/services" className="py-2 border-b border-gray-100" onClick={() => setIsMenuOpen(false)}>OUR SERVICES</Link>
              <Link href="/verticals" className="py-2 border-b border-gray-100" onClick={() => setIsMenuOpen(false)}>INDUSTRY VERTICALS</Link>
              <Link href="/contact" className="py-2" onClick={() => setIsMenuOpen(false)}>CONTACT US</Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}