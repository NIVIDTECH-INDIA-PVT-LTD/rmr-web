import Image from "next/image";

export default function HeroSection() {
  return (
    <section
      //   className="relative h-screen bg-cover bg-no-repeat bg-center overflow-hidden"
      className="relative h-auto bg-cover bg-no-repeat bg-center overflow-hidden"
      style={{ backgroundImage: "url('/images/fullbg.png')" }}
    >
      <div className="w-full grid grid-cols-1 md:grid-cols-2 items-center h-full px-4 py-8 md:py-0 md:px-0">
        {/* Left content - vertically centered */}
        <div className="flex items-center justify-center h-full order-2 md:order-1">
          <div className="text-white">
            <p className="text-[16px] md:text-[18px] font-medium underline leading-[100%] mb-2 decoration-solid decoration-[0.5px] decoration-white">
              Delivering Results That Matter
            </p>

            <h1 className="text-3xl md:text-4xl lg:text-[60px] font-[Figtree] font-bold py-2 leading-[110%] md:leading-[100%] align-middle tracking-[0]">
              Unlock The Future <br /> Of Business Consulting
            </h1>
            <p className="font-[500] text-[16px] md:text-[18px] leading-[140%] md:leading-[100%] align-middle text-white/90 py-4 pr-0 md:pr-4 max-w-lg">
              We specialize in providing tailored consulting services that drive
              success and transformation for businesses of all sizes.
            </p>
            <div className="py-4 flex">
              <div className="relative inline-block">
                {/* White curve behind the button */}
                <div className="absolute inset-0 flex justify-center items-end pointer-events-none z-0">
                  <div className="w-full h-[40px] md:h-[45px] bg-white rounded-full translate-y-[6px]"></div>
                </div>

                {/* Button */}
                <button className="relative z-10 bg-[#CD4D4A] hover:bg-red-800 transition px-4 md:px-6 py-3 cursor-pointer text-[14px] md:text-[18px] leading-[100%] text-center align-middle uppercase rounded-full font-semibold text-white">
                  SCHEDULE A CONSULTATION
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right image - vertically centered */}
        <div className="flex items-center justify-center h-full order-1 md:order-2 mb-8 md:mb-0">
          <Image
            src="/images/homeright.png"
            alt="Hero"
            width={600}
            height={400}
            className="w-full h-auto md:max-h-none object-contain"
            priority
          />
        </div>
      </div>
    </section>
  );
}