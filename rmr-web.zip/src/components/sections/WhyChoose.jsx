// import { CheckCircle } from 'lucide-react';

// const features = [
//   'Customized research reports',
//   'Affordable pricing',
//   'Experienced analysts',
//   '24/7 customer support',
// ];

// export default function WhyChoose() {
//   return (
//     <section className="bg-white py-20 px-6">
//       <div className="max-w-7xl mx-auto text-center">
//         <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
//           Why Choose Root Market Research?
//         </h2>
//         <p className="text-gray-600 max-w-2xl mx-auto mb-10">
//           We deliver market intelligence that empowers businesses with actionable insights.
//         </p>

//         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mt-8">
//           {features.map((feature, index) => (
//             <div
//               key={index}
//               className="bg-gray-100 p-6 rounded-lg shadow-sm hover:shadow-md transition"
//             >
//               <CheckCircle className="text-red-600 mb-3 w-6 h-6 mx-auto" />
//               <p className="text-gray-800 font-medium">{feature}</p>
//             </div>
//           ))}
//         </div>
//       </div>
//     </section>
//   );
// }
