import Header from '@/components/Header';
import HeroSection from '@/components/sections/HeroSection';
import WhyChoose from '@/components/sections/WhyChoose';

export default function Home() {
  return (
    <>
      <Header />
      <HeroSection />
      {/* <WhyChoose/> */}
    </>
  );
}
